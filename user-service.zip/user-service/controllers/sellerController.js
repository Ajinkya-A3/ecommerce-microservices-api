const User = require("../models/User");
const bcrypt = require("bcryptjs");

// Seller registration
const registerSeller = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    let user = await User.findOne({ email });
    if (user) return res.status(400).json({ message: "User already exists" });

    const hashedPassword = await bcrypt.hash(password, 10);
    user = new User({ name, email, password: hashedPassword, role: "seller" });
    await user.save();

    res.status(201).json({ message: "Seller registered successfully" });

  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

module.exports = { registerSeller };
